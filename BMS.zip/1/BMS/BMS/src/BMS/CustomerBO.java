package BMS;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class CustomerBO {
	
	public static String  id_generation(Set<String> u)
	{
		int i=100;
		String id="R-";
		id="R-"+String.valueOf(i);
		while(u.contains(id))
		{
			i++;
			id="R-"+String.valueOf(i);
		}
	    
		return id;
	}
	public static long acc_no_generation(Set<Long> u1)
	{
		long a=1000000000000000L;
	   while(u1.contains(a))
	   {
		   a++;
	   }
	   return a;
	}
	public static int loan_id_generation(Set<Integer> u1)
	{
		int s=1000; 
		 while(u1.contains(s))
		   {
			   s++;
		   }
	    return s;
	}
}
