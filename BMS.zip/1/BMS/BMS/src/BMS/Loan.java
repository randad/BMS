package BMS;

import java.sql.Date;

public class Loan {
protected String Loan_type;
protected double Loan_amount;
protected Date Loan_apply_date;
protected Date Loan_issue_date;
protected double rate_of_intrest;
protected int duration_of_loan;
public String getLoan_type() {
	return Loan_type;
}
public void setLoan_type(String loan_type) {
	Loan_type = loan_type;
}
public double getLoan_amount() {
	return Loan_amount;
}
public void setLoan_amount(double loan_amount) {
	Loan_amount = loan_amount;
}
public Date getLoan_apply_date() {
	return Loan_apply_date;
}
public void setLoan_apply_date(Date loan_apply_date) {
	Loan_apply_date = loan_apply_date;
}
public Date getLoan_issue_date() {
	return Loan_issue_date;
}
public void setLoan_issue_date(Date loan_issue_date) {
	Loan_issue_date = loan_issue_date;
}
public double getRate_of_intrest() {
	return rate_of_intrest;
}
public void setRate_of_intrest(double rate_of_intrest) {
	this.rate_of_intrest = rate_of_intrest;
}
public int getDuration_of_loan() {
	return duration_of_loan;
}
public void setDuration_of_loan(int duration_of_loan) {
	this.duration_of_loan = duration_of_loan;
}
public Loan(String loan_type, double loan_amount, Date loan_apply_date, Date loan_issue_date, double rate_of_intrest,
		int duration_of_loan) {
	super();
	Loan_type = loan_type;
	Loan_amount = loan_amount;
	Loan_apply_date = loan_apply_date;
	Loan_issue_date = loan_issue_date;
	this.rate_of_intrest = rate_of_intrest;
	this.duration_of_loan = duration_of_loan;
}
public Loan() {
	super();
}


}
