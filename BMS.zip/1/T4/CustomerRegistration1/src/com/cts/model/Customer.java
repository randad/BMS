package com.cts.model;
import java.util.Date;


public class Customer {
	private String custId;
	private String Name;
	private String UserName;
	private String Password;
	private String GuardianType;
	private String GuardianName;
	private String Address;
	private String CitizenShip;
	private String State;
	private String Country;
	private String Email;
	private String Gender;
	private String MartialStatus;
	private String ContactNumber;
	private Date DateofBirth;
	//private Date RegistrationDate;
	private String AccountNumber;
	private String Accounttype;
	private String BranchName;
	private String Citizenstatus;
	private float InitialDepositAmount;
	private String IdentificationProofType;
	private String IdentificationocumentNo;
	private String Referenceaccountholdername;
	private String ReferenceAccountHolderaccNo;
	private String ReferenceAccountHolderAddress;
	
	
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getGuardianType() {
		return GuardianType;
	}
	public void setGuardianType(String guardianType) {
		GuardianType = guardianType;
	}
	public String getGuardianName() {
		return GuardianName;
	}
	public void setGuardianName(String guardianName) {
		GuardianName = guardianName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getCitizenShip() {
		return CitizenShip;
	}
	public void setCitizenShip(String citizenShip) {
		CitizenShip = citizenShip;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getMartialStatus() {
		return MartialStatus;
	}
	public void setMartialStatus(String martialStatus) {
		MartialStatus = martialStatus;
	}
	public String getContactNumber() {
		return ContactNumber;
	}
	public void setContactNumber(String contactNumber) {
		ContactNumber = contactNumber;
	}
	public Date getDateofBirth() {
		return DateofBirth;
	}
	public void setDateofBirth(Date dateofBirth) {
		DateofBirth = dateofBirth;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public String getAccounttype() {
		return Accounttype;
	}
	public void setAccounttype(String accounttype) {
		Accounttype = accounttype;
	}
	public String getBranchName() {
		return BranchName;
	}
	public void setBranchName(String branchName) {
		BranchName = branchName;
	}
	public String getCitizenstatus() {
		return Citizenstatus;
	}
	public void setCitizenstatus(String citizenstatus) {
		Citizenstatus = citizenstatus;
	}
	public float getInitialDepositAmount() {
		return InitialDepositAmount;
	}
	public void setInitialDepositAmount(float initialDepositAmount) {
		InitialDepositAmount = initialDepositAmount;
	}
	public String getIdentificationProofType() {
		return IdentificationProofType;
	}
	public void setIdentificationProofType(String identificationProofType) {
		IdentificationProofType = identificationProofType;
	}
	public String getIdentificationocumentNo() {
		return IdentificationocumentNo;
	}
	public void setIdentificationocumentNo(String identificationocumentNo) {
		IdentificationocumentNo = identificationocumentNo;
	}
	public String getReferenceaccountholdername() {
		return Referenceaccountholdername;
	}
	public void setReferenceaccountholdername(String referenceaccountholdername) {
		Referenceaccountholdername = referenceaccountholdername;
	}
	public String getReferenceAccountHolderaccNo() {
		return ReferenceAccountHolderaccNo;
	}
	public void setReferenceAccountHolderaccNo(String referenceAccountHolderaccNo) {
		ReferenceAccountHolderaccNo = referenceAccountHolderaccNo;
	}
	public String getReferenceAccountHolderAddress() {
		return ReferenceAccountHolderAddress;
	}
	public void setReferenceAccountHolderAddress(
			String referenceAccountHolderAddress) {
		ReferenceAccountHolderAddress = referenceAccountHolderAddress;
	}

	


}
