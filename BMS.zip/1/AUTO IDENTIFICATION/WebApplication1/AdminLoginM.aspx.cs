﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataLayer d3 = new DataLayer();
               
                    if (d3.LoginA(login1a.Text,pass1a.Text)==1)
                    {
                        Response.Write(" successful");
                        Session["loginadmin"] = "yes1";
                        Response.Redirect("AdminDataViewM.aspx");
                    }

                    else
                    {
                        Response.Write(" unsuccessfull");
                    }
            
        }
    }
}